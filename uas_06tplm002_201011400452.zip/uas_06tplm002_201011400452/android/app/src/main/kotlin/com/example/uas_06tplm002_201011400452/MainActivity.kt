package com.example.uas_06tplm002_201011400452

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
